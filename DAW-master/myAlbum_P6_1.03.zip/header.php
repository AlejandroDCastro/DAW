<?php

	echo "<header>
    <a href='index.php'><img src='img/logo.png' class='logo'></a>
    <a class='float_right margin_top_icon' href='buscar.php'><i class='fa fa-search fa-lg'></i></a>
    <a class='float_right margin_top_icon margin_right_icon' href='menu.php'><i class='fa fa-user fa-lg'></i></a>
	</header>";
	
?>