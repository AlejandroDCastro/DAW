<?php

	echo "<header>
    <a href='index.php'><img src='img/logo.png' class='logo'></a>
    <a class='float_right margin_top_icon' href='buscar.php'><i class='fa fa-search fa-lg'></i></a>
  	</header>";
	
?>