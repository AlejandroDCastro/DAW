<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detalle foto | myAlbum</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" type="text/css" href="css/print.css" media="print"/>
    <link rel="alternate stylesheet" type="text/css" href="css/altoContraste.css" title="Alto contraste">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="shortcut icon" type="image/png" href="img/favicon.png"/>
</head>
<body>
<?php 
    include('headerSinLogear.php');
?>
<section>
    <div class="split-foto izq-foto">
        <div class="margin_info_foto">
            <div class="row">
                <h3 style=" float: left; width: 80%; margin-top: 7%">Álbum</h3>
                <div style="float: left; width: 10%; margin-bottom: 2%">
                    <span style="font-size: 2em;">23</span><br>
                    <span>ENE</span>
                </div>
                <br>
            </div>
            <h2 style="text-align: left; margin-top: 0; margin-bottom: 0">Titulo de la foto</h2><br>
            <div style="text-align: left" class="fontSize">Lorem ipsum dolor sit amet consectetur adipiscing elit, sed
                inceptos malesuada praesent primis. Eu pharetra lacinia sociosqu ac cum commodo laoreet ridiculus
                praesent, auctor fermentum enim platea quisque pulvinar ad tortor, nibh aliquet orci mauris fringilla
                nisl inceptos odio.
            </div>
            <br>
            <div><i style="margin-right: 2%;" class="fa fa-user fa-lg"></i><span>Usuario</span></div>
        </div>
    </div>

    <?php 

        if(isset($_GET['foto']) && $_GET['foto']==1){
            
            echo '<div class="split-foto dcha-foto"></div>';
        }else if(isset($_GET['foto']) && $_GET['foto']==2){

            echo '<div class="split-foto dcha-foto2"></div>';
            
        }
    ?>
    
</section>
</body>
</html>